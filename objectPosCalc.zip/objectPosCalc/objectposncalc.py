print('This program calculates the position of an object over time')

doCalc = True
while (doCalc):
  while (True):
    
    try:
      intpos = float(input('Enter the initial position: '))
  
    except ValueError:
      print('Only numerical values without units are accepted')
  
    else:
      break

  while (True):
  
    try:
      intvel = float(input('Enter the initial velocity: ' ))
  
    except ValueError:
      print('Only numerical values without units are accepted')
  
    else:
      break

  while (True):
  
    try:
      accel = float(input("Enter the object's acceleration: "))

    except ValueError:
      print('Only numerical values without units are accepted')
  
    else:
      break

  while (True):
  
    try:
      time = float(input('Enter the time elapsed: '))
      if (time < 0):
        print('Time value must be positive')
        continue
  
    except ValueError:
        print('Only numerical values without units are accepted')

    else:
      break
  
  finpos = intpos + intvel * time + 0.5 * accel * time ** 2

  print('The final object position is', finpos)
  anthCalc = input('Would you like to perform another calculation? (y/n): ')
  if (anthCalc != 'y'):
    doCalc = False
